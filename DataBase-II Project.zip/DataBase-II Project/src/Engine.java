public class Engine {
    int engineDisplacement;
    int HP;
    String FuelType;
    int Cylinders;

    public Engine(int engineDisplacement, int  HP, String FuelType, int Cylinders){
        super();
        this.engineDisplacement= engineDisplacement;
        this.HP=HP;
        this.FuelType=FuelType;
        this.Cylinders=Cylinders;

    }

    public int getEngineDisplacement(){
        return engineDisplacement;
    }
    public void setEngineDisplacement(int engineDisplacement){
        this.engineDisplacement=engineDisplacement;
    }
    public int getHP(){
        return HP;
    }
    public void setHP(int HP){
        this.HP=HP;
    }
    public String setFuelType(){
        return FuelType;
    }
    public void setFuelType(String FuelType) {
        this.FuelType = FuelType;
    }
    public int getCylinders(){
        return Cylinders;
    }
    public void setCylinders(int Cylinders){
        this.Cylinders=Cylinders;
    }




}
