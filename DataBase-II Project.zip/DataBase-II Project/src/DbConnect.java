import java.sql.*;
import java.util.Scanner;

public class DbConnect {

    public void showCar(){

        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/database_homework?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey", "root", "");
            System.out.println("DB Connected");

            String stmt = "SELECT * FROM car";
            ResultSet rs = conn.createStatement().executeQuery(stmt);
            while (rs.next()){
                System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4)+" "+rs.getInt(5)+rs.getInt(6));
            }

        }catch (Exception e){
            System.out.println("DB Failed");
            System.out.println(e.getMessage());

        }

    }

    public void showEngine() {

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/database_homework?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey", "root", "");
            System.out.println("DB Connected");

            String stmt = "SELECT * FROM engine";
            ResultSet rs = conn.createStatement().executeQuery(stmt);
            while (rs.next()) {
                System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3) + " " + rs.getInt(4) + " " + rs.getInt(5));
            }

        } catch (Exception e) {
            System.out.println("DB Failed");
            System.out.println(e.getMessage());

        }

    }

    public void showTire() {

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/database_homework?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey", "root", "");
            System.out.println("DB Connected");

            String stmt = "SELECT * FROM tire";
            ResultSet rs = conn.createStatement().executeQuery(stmt);
            while (rs.next()) {
                System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3) + " " + rs.getInt(4) + " " + rs.getInt(5));
            }

        } catch (Exception e) {
            System.out.println("DB Failed");
            System.out.println(e.getMessage());

        }

    }



    public void AddCar(){
        try
        {
            // create a mysql database connection
            String myDriver = "org.gjt.mm.mysql.Driver";
            String myUrl = "jdbc:mysql://localhost/database_homework?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey";
            Class.forName(myDriver);
            Connection conn = DriverManager.getConnection(myUrl, "root", "");

            Statement st = conn.createStatement();
            String color;
            String make;
            String model;
            int T_ID;
            int E_ID;

            Scanner input = new Scanner(System.in);

            System.out.print("Car Color:");
            color = input.nextLine();
            System.out.print("Car Make:");
            make = input.nextLine();
            System.out.print("Car Model");
            model = input.nextLine();
            System.out.print("Car Tire ID:");
            T_ID = input.nextInt();
            System.out.print("Car Engine ID:");
            E_ID = input.nextInt();

            st.executeUpdate("INSERT INTO users (color, make, model, T_ID, E_ID) "
                    +"VALUES ('"+color+"', '"+make+"', '"+model+"',"+T_ID+","+E_ID+")");

            conn.close();
        }
        catch (Exception e)
        {
            System.err.println("Got an exception!");
            System.err.println(e.getMessage());
        }

    }

    public void AddEngine(){
        try
        {
            // create a mysql database connection
            String myDriver = "org.gjt.mm.mysql.Driver";
            String myUrl = "jdbc:mysql://localhost/database_homework?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey";
            Class.forName(myDriver);
            Connection conn = DriverManager.getConnection(myUrl, "root", "");

            Statement st = conn.createStatement();
            int engineDisplacement;
            int HP;
            String FuelType;
            int T_ID;
            int Cylinders;

            Scanner input = new Scanner(System.in);

            System.out.print("Engine Displacement:");
            engineDisplacement	 = input.nextInt();
            System.out.print("Engine Horse Power:");
            HP = input.nextInt();
            System.out.print("Engine Fuel Type:");
            FuelType = input.nextLine();
            System.out.print("Engine Cylinders:");
            Cylinders = input.nextInt();


            st.executeUpdate("INSERT INTO users (color, make, model, T_ID, E_ID) "
                    +"VALUES ("+engineDisplacement+","+HP+",'"+FuelType+"',"+Cylinders+")");

            conn.close();
        }
        catch (Exception e)
        {
            System.err.println("Got an exception!");
            System.err.println(e.getMessage());
        }

    }

    public void AddTire(){
        try
        {

            String myDriver = "org.gjt.mm.mysql.Driver";
            String myUrl = "jdbc:mysql://localhost/database_homework?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey";
            Class.forName(myDriver);
            Connection conn = DriverManager.getConnection(myUrl, "root", "");

            Statement st = conn.createStatement();
            int pressure;
            String color;
            int diameter;
            String treadType;

            Scanner input = new Scanner(System.in);

            System.out.print("Tire Pressure:");
            pressure	= input.nextInt();
            System.out.print("Tire color:");
            color = input.nextLine();
            System.out.print("Tire diameter:");
            diameter = input.nextInt();
            System.out.print("Tire Tread Type:");
            treadType = input.nextLine();


            st.executeUpdate("INSERT INTO users (color, make, model, T_ID, E_ID) "
                    +"VALUES ("+pressure+",'"+color+"',"+diameter+",'"+treadType+"')");

            conn.close();
        }
        catch (Exception e)
        {
            System.err.println("Got an exception!");
            System.err.println(e.getMessage());
        }

    }

    }


