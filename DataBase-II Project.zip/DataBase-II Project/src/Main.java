import java.util.Scanner;

public class Main {
 public static void main(String[] args){

     Scanner input = new Scanner(System.in);
     DbConnect db1=new DbConnect();
int n1=0;
int n2=0;
     System.out.print("What Do you What?\n(1-Show   2-Add):");
n1= input.nextInt();
     if(n1==1) {
         System.out.print("What Do you Show?\n(1-Engine   2-Tires   3-Cars):");
         n2= input.nextInt();
            if(n2==1){
                db1.showEngine();
            }
            else if(n2==2){
                db1.showTire();
            }
            else if(n2==3){
                db1.showCar();
            }
     }
     if(n1==2) {
         System.out.print("What Do you ADD?\n(1-Engine   2-Tires   3-Cars):");
         n2= input.nextInt();
         if(n2==1){
             db1.AddEngine();
         }
         else if(n2==2){
             db1.AddTire();
         }
         else if(n2==3){
             db1.AddCar();
         }
     }

     Tire t1 = new Tire(0,"black",18,"zigzag");
     Tire t2 = new Tire(0,"red",18,"zigzag");
     Tire t3 = new Tire(0,"white",18,"zigzag");
     Tire t4 = new Tire(0,"pink",18,"zigzag");
     Tire[] tires={t1,t2,t3,t4};

     Engine e1 =new Engine(1600,300,"diesel",8);
     Engine e2 =new Engine(1200,250,"gasoline",8);
     Engine e3 =new Engine(2400,650,"gasoline",16);
     Engine e4 =new Engine(1600,250,"diesel",6);
     Engine e5 =new Engine(2000,450,"gasoline",12);
     Engine[] engines={e1,e2,e3,e4,e5};

     t1.inflate(50);



     Car supercar=new Car("black","Ford",tires,engines);
     boolean started=false;


     if(started==false){
         System.out.println("The car is running");
     }
     else {
         System.out.println("The car falled to start");
     }


 }

}
